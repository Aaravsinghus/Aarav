# Target: Minecraft Java 1.21.11

This source has been retargeted in `gradle.properties` to Minecraft 1.21.11 and Java 21.

## Auto-eat behavior
- Starts eating normal food when hunger is 14 or lower.
- Searches the normal inventory and hotbar.
- Explicitly refuses both Golden Apple and Enchanted Golden Apple.
- Temporarily moves inventory food to hotbar slot 8 (index 7), eats it, then restores the previous selected slot.

## Important build note
The supplied upstream source tree contained mappings/APIs from a newer Minecraft line than 1.21.11 even though its filename said 1.20.0. Therefore this is a **1.21.11-targeted source patch**, not a claim that every upstream class has already been remapped for 1.21.11. A matching 1.21.11 Baritone source/mappings baseline is required for a guaranteed clean build.
