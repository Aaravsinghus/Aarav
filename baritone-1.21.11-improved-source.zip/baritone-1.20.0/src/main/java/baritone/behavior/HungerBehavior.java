/*
 * Automatic hunger handling for Baritone.
 *
 * Normal food may be consumed when hunger is low. Golden apples are explicitly
 * excluded and are never used as automatic food.
 */
package baritone.behavior;

import baritone.Baritone;
import baritone.api.event.events.TickEvent;
import baritone.api.utils.Helper;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;

public final class HungerBehavior extends Behavior implements Helper {

    // Start eating at or below this food level. Full hunger is 20.
    private static final int EAT_AT_OR_BELOW = 14;
    private static final int FOOD_HOTBAR_SLOT = 7;
    private int previousHotbarSlot = -1;
    private int restoreTicks = 0;

    public HungerBehavior(Baritone baritone) {
        super(baritone);
    }

    @Override
    public void onTick(TickEvent event) {
        if (event.getType() != TickEvent.Type.IN || ctx.player() == null) {
            return;
        }

        LocalPlayer player = ctx.player();

        // Never interfere while the player is already using an item.
        if (player.isUsingItem()) {
            if (restoreTicks > 0) {
                restoreTicks--;
            }
            return;
        }

        // Restore the previous selected slot shortly after finishing food.
        if (restoreTicks > 0) {
            restoreTicks--;
            if (restoreTicks == 0 && previousHotbarSlot >= 0) {
                player.getInventory().setSelectedSlot(previousHotbarSlot);
                previousHotbarSlot = -1;
            }
            return;
        }

        if (player.getFoodData().getFoodLevel() > EAT_AT_OR_BELOW) {
            return;
        }

        int foodSlot = baritone.getInventoryBehavior().findFoodForAutoEat();
        if (foodSlot < 0) {
            return;
        }

        int currentSlot = player.getInventory().getSelectedSlot();
        if (foodSlot < 9) {
            if (foodSlot != currentSlot) {
                previousHotbarSlot = currentSlot;
            }
            player.getInventory().setSelectedSlot(foodSlot);
        } else {
            previousHotbarSlot = currentSlot;
            if (!baritone.getInventoryBehavior().selectFoodForAutoEat(foodSlot, FOOD_HOTBAR_SLOT)) {
                previousHotbarSlot = -1;
                return;
            }
            player.getInventory().setSelectedSlot(FOOD_HOTBAR_SLOT);
        }

        ItemStack held = player.getMainHandItem();
        // Re-check here so a golden apple can never slip through due to an inventory race.
        if (held.isEmpty()
                || held.getItem() == net.minecraft.world.item.Items.GOLDEN_APPLE
                || held.getItem() == net.minecraft.world.item.Items.ENCHANTED_GOLDEN_APPLE
                || !held.getItem().components().has(net.minecraft.core.component.DataComponents.FOOD)) {
            if (previousHotbarSlot >= 0) {
                player.getInventory().setSelectedSlot(previousHotbarSlot);
                previousHotbarSlot = -1;
            }
            return;
        }

        baritone.getPlayerContext().playerController().processRightClick(player, player.level(), InteractionHand.MAIN_HAND);
        // Give vanilla eating enough ticks to finish before restoring the old slot.
        restoreTicks = 40;
    }
}
