#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -f build.log ] || { echo "build.log nahi mila, pehle: bash build.sh"; exit 1; }
echo "--- last lines ---"; tail -3 build.log
echo
if grep -q "^DONE" build.log; then
  if grep -q "BUILD SUCCESSFUL" build.log; then echo "RESULT: SUCCESS"; echo "--- dist/ ---"; ls -la dist/ 2>/dev/null
  else echo "RESULT: FAILED"; grep -n -A8 "What went wrong" build.log | head -25; fi
else
  echo "RESULT: abhi chal raha hai..."
fi
