#!/usr/bin/env bash
# One-shot build for Baritone Fabric (no proguard). Runs fully in background.
set -u
cd "$(dirname "$0")"

# Pick Java 21 automatically
if [ -f /usr/local/sdkman/bin/sdkman-init.sh ]; then
  source /usr/local/sdkman/bin/sdkman-init.sh
  sdk use java 21.0.5-tem >/dev/null 2>&1
fi
export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")"
export PATH="$JAVA_HOME/bin:$PATH"

chmod +x gradlew
./gradlew --stop >/dev/null 2>&1
rm -f build.log

nohup setsid bash -c '
  ./gradlew :fabric:build -x test -x javadoc --console=plain > build.log 2>&1
  echo "EXIT_CODE=$?" >> build.log
  echo DONE >> build.log
' >/dev/null 2>&1 &

echo "Build started in background. Check with:  bash status.sh"
