/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.launch;

import net.fabricmc.api.ClientModInitializer;

/**
 * Fabric client entrypoint for Baritone.
 * <p>
 * The actual pathing engine is bootstrapped by {@code MixinMinecraft}, which is
 * loader-agnostic and applies on Fabric, Forge, and NeoForge alike. This class exists
 * so that Fabric Loader, Fabric API, and tools like Mod Menu correctly recognize
 * Baritone as a registered client-side mod, and so any startup failure is attributed
 * to this class in logs/crash reports rather than surfacing anonymously from a mixin.
 * <p>
 * This must implement {@link ClientModInitializer}, not {@code ModInitializer}: Baritone's
 * bootstrap ({@code BaritoneProvider}) calls {@code Minecraft.getInstance()}, which is only
 * valid on the physical client. A plain {@code ModInitializer} also runs on dedicated
 * servers and would NPE there.
 *
 * @author Brady
 * @since 7/31/2018
 */
public class BaritoneFabric implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // Intentionally minimal: MixinMinecraft#postInit already triggers
        // BaritoneAPI.getProvider().getPrimaryBaritone() when the Minecraft client
        // instance is constructed. Touching BaritoneAPI here as well is harmless
        // (BaritoneProvider is idempotent per Minecraft instance) and guarantees
        // that any exception during first-time init is logged against this
        // entrypoint instead of failing silently inside mixin injection.
        baritone.api.BaritoneAPI.getProvider().getPrimaryBaritone();
    }
}
